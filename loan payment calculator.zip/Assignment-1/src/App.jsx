import React, { useState } from 'react';
import InputForm from './components/LoanForm';
import LoanCalculator from './components/LoanCalculator';

function App() {
  const [monthlyPayment, setMonthlyPayment] = useState(null);
  const [totalPayment, setTotalPayment] = useState(null);
  const [totalInterest, setTotalInterest] = useState(null);

  const calculateLoan = (loanAmount, interestRate, loanTerm) => {
    const monthlyInterestRate = interestRate / 100 / 12;
    const numberOfPayments = loanTerm * 12;
    const monthlyPayment = (loanAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, numberOfPayments)) / (Math.pow(1 + monthlyInterestRate, numberOfPayments) - 1);
    const totalPayment = monthlyPayment * numberOfPayments;
    const totalInterest = totalPayment - loanAmount;

    setMonthlyPayment(monthlyPayment.toFixed(2));
    setTotalPayment(totalPayment.toFixed(2));
    setTotalInterest(totalInterest.toFixed(2));
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100">
      <InputForm onCalculate={calculateLoan} />
      {monthlyPayment !== null && (
        <LoanCalculator
          monthlyPayment={monthlyPayment}
          totalPayment={totalPayment}
          totalInterest={totalInterest}
        />
      )}
    </div>
  );
}

export default App;
