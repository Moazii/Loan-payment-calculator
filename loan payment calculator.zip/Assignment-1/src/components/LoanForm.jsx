import React, { useState } from 'react';

const InputForm = () => {
  const [loanAmount, setLoanAmount] = useState('');
  const [interestRate, setInterestRate] = useState('');
  const [loanTerm, setLoanTerm] = useState('');
  const [monthlyPayment, setMonthlyPayment] = useState(null);
  const [totalPayment, setTotalPayment] = useState(null);
  const [totalInterest, setTotalInterest] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    calculateLoan(Number(loanAmount), Number(interestRate), Number(loanTerm));
  };

  const calculateLoan = (loanAmount, interestRate, loanTerm) => {
    const monthlyInterestRate = interestRate / 100 / 12;
    const numberOfPayments = loanTerm * 12;
    const monthlyPayment = (loanAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, numberOfPayments)) / (Math.pow(1 + monthlyInterestRate, numberOfPayments) - 1);
    const totalPayment = monthlyPayment * numberOfPayments;
    const totalInterest = totalPayment - loanAmount;

    setMonthlyPayment(monthlyPayment.toFixed(2));
    setTotalPayment(totalPayment.toFixed(2));
    setTotalInterest(totalInterest.toFixed(2));
  };

  return (
    <div className="h-screen w-screen bg-gray-400 py-6 flex flex-col justify-center sm:py-12">
      <h1 className='bg-slate-600 text-center my-5 mt-0 py-6 rounded-full text-white text-2xl italic'>LOAN PAYMENT CALCULATOR By MOAZ ASLAM</h1>
      <div className="relative py-3 sm:max-w-xl sm:mx-auto">
        <div className="absolute inset-0 bg-gradient-to-r from-gray-400 to-gray-700 shadow-lg transform -skew-y-6 sm:skew-y-0 sm:-rotate-6 sm:rounded-3xl w-full"></div>
        <div className="relative px-4 py-10 bg-white shadow-lg sm:rounded-3xl sm:p-20">
          <div className="max-w-md mx-auto">
            <div>
              <h1 className="text-2xl font-semibold">Loan Payment Calculator</h1>
            </div>
            <div className="divide-y divide-gray-200">
              <div className="py-8 text-base leading-6 space-y-4 text-gray-700 sm:text-lg sm:leading-7">
                <form onSubmit={handleSubmit}>
                  <div className="relative">
                    <input
                      autoComplete="off"
                      id="loanAmount"
                      name="loanAmount"
                      type="number"
                      value={loanAmount}
                      min={0}
                      onChange={(e) => setLoanAmount(e.target.value)}
                      className="peer placeholder-transparent h-10 w-full text-gray-900 focus:outline-none"
                      placeholder="Loan Amount"
                      required
                    />
                    <label
                      htmlFor="loanAmount"
                      className="absolute left-0 -top-3.5 text-gray-600 text-sm"
                    >
                      Loan Amount$
                    </label>
                  </div>
                  <div className="relative">
                    <input
                      autoComplete="off"
                      id="interestRate"
                      name="interestRate"
                      type="number"
                      value={interestRate}
                      min={0}
                      onChange={(e) => setInterestRate(e.target.value)}
                      className="peer placeholder-transparent h-10 w-full text-gray-900 focus:outline-none"
                      placeholder="Interest Rate"
                      required
                    />
                    <label
                      htmlFor="interestRate"
                      className="absolute left-0 -top-3.5 text-gray-600 text-sm"
                    >
                      Interest Rate Per Year %
                    </label>
                  </div>
                  <div className="relative">
                    <input
                      autoComplete="off"
                      id="loanTerm"
                      name="loanTerm"
                      type="number"
                      value={loanTerm}
                      onChange={(e) => setLoanTerm(e.target.value)}
                      className="peer placeholder-transparent h-10 w-full text-gray-900 focus:outline-none"
                      placeholder="Loan Term"
                      required
                    />
                    <label
                      htmlFor="loanTerm"
                      className="absolute left-0 -top-3.5 text-gray-600 text-sm"
                    >
                      Loan Term in year
                    </label>
                  </div>
                  <div className="relative">
                    <button
                      type="submit"
                      className="bg-gray-700 text-white rounded-md px-2 py-1 mt-4"
                    >
                      Calculate
                    </button>
                  </div>
                </form>
                {monthlyPayment && (
                  <div className="mt-4">
                    <h2 className="text-xl font-semibold mb-4 ">Loan Calculation Results</h2>
                    <p>Total principle amount to pay: ${loanAmount}</p>
                    <p>Total Interest to pay: ${totalInterest}</p>
                    <p>____________________________________</p>
                    <br />
                    <p>Total Loan amount to pay: ${totalPayment}</p>
                    <br />
                    
                    <h2 className='text-center text-2xl'>Monthly Payment: ${monthlyPayment}</h2>
                    
                    
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InputForm;
