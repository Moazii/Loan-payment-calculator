import React from 'react';

const LoanCalculator = ({ monthlyPayment, totalPayment, totalInterest }) => {
  return (
    <div className="w-full sm:w-1/2 mt-8 bg-white p-6 rounded-md shadow-md">
      <h2 className="text-2xl font-semibold mb-4">Loan Calculation Results</h2>
      <p>Monthly Payment: ${monthlyPayment}</p>
      <p>Total Payment: ${totalPayment}</p>
      <p>Total Interest: ${totalInterest}</p>
    </div>
  );
};

export default LoanCalculator;
